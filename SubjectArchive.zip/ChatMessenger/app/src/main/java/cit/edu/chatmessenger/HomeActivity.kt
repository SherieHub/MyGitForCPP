package cit.edu.chatmessenger

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class HomeActivity : Activity() {

    private lateinit var subjectlist: MutableList<Subject>
    private lateinit var adapter: SubjectListRecyclerViewAdapter
    private lateinit var tv_noSubjects: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val btn_add = findViewById<Button>(R.id.btn_addSub)
        val btn_profile = findViewById<Button>(R.id.btn_profile)
        val btn_logOut = findViewById<Button>(R.id.btn_logOut)
        tv_noSubjects = findViewById(R.id.textview_noSub)
        val recyclerview = findViewById<RecyclerView>(R.id.recyclerview_subjectlist)

        subjectlist = mutableListOf()
        adapter = SubjectListRecyclerViewAdapter(
                subjectlist,
                onClick = {subject ->
                    startActivity(Intent(this, ClassActivity::class.java))
                }
            )

        recyclerview.adapter = adapter
        recyclerview.layoutManager = LinearLayoutManager(this)

        btn_profile.setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }

        btn_logOut.setOnClickListener{
            val builder = AlertDialog.Builder(this)
            builder.setMessage("Are you sure you want to logout?")
            builder.setTitle("Alert !")
            builder.setCancelable(false)
            builder.setPositiveButton("Yes"){
                    _, _ -> startActivity(Intent(this, LoginActivity::class.java))
            }

            builder.setNegativeButton("No"){
                    dialog, _ -> dialog.cancel()
            }

            val alertDialog = builder.create()
            alertDialog.show()
        }

        btn_add.setOnClickListener {
            val addSubjectIntent = Intent(this, AddSubjectActivity::class.java)
            startActivityForResult(addSubjectIntent, 100)
        }
        updateNoSubjectsVisibility()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == 100 && resultCode == Activity.RESULT_OK && data != null) {
            val subject = data.getSerializableExtra("subject") as? Subject
            subject?.let {
                subjectlist.add(it)
                adapter.notifyItemInserted(subjectlist.size - 1)
                updateNoSubjectsVisibility()
            }
        }
    }

    private fun updateNoSubjectsVisibility() {
        tv_noSubjects.text = if (subjectlist.isEmpty()) "No subjects available." else ""
    }
}

