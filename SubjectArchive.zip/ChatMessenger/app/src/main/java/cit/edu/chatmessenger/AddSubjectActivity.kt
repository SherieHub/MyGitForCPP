package cit.edu.chatmessenger

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class AddSubjectActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_subject)

        val et_subjectname = findViewById<EditText>(R.id.et_subjectname)
        val et_subjectcode = findViewById<EditText>(R.id.et_subjectcode)
        val et_gradelevel = findViewById<EditText>(R.id.et_gradelevel)
        val et_roomnumber = findViewById<EditText>(R.id.et_roomnumber)
        val et_time = findViewById<EditText>(R.id.et_time)
        val btn_save = findViewById<Button>(R.id.btn_save)

        btn_save.setOnClickListener {
            if (et_subjectname.text.toString().isEmpty() ||
                et_subjectcode.text.toString().isEmpty() ||
                et_roomnumber.text.toString().isEmpty() ||
                et_time.text.toString().isEmpty()
            ) {
                Toast.makeText(
                    this,
                    "Subject Name, Subject Code, Room Number, and Time must not be empty!",
                    Toast.LENGTH_LONG
                ).show()
                return@setOnClickListener
            }

            val subject = Subject(
                et_subjectname.text.toString(),
                et_subjectcode.text.toString(),
                et_gradelevel.text.toString(),
                et_roomnumber.text.toString(),
                et_time.text.toString()
            )

            val resultIntent = Intent()
            resultIntent.putExtra("subject", subject)
            setResult(Activity.RESULT_OK, resultIntent)
            finish()
        }
    }
}

