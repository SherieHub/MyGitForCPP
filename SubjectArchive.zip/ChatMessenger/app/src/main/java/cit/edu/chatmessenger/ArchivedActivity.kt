package cit.edu.chatmessenger

import android.app.Activity
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ArchivedActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_archived)

        val archivedActivity = findViewById<RecyclerView>(R.id.recyclerview_archivedActivities)
        val archivedlist = (application as MyApplication).archivedActivities

        val adapter = ArchivedRecyclerViewAdapter(archivedlist)

        archivedActivity.adapter = adapter
        archivedActivity.layoutManager = LinearLayoutManager(this)
    }
}