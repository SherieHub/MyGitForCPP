package cit.edu.chatmessenger

import android.app.Activity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.RecyclerView

class ArchivedRecyclerViewAdapter(
    private val archivedActivities: MutableList<ActivityDetails>
): RecyclerView.Adapter<ArchivedRecyclerViewAdapter.ArchivedViewHolder>(){

    class ArchivedViewHolder(view: View): RecyclerView.ViewHolder(view){
        val title = view.findViewById<TextView>(R.id.textview_title)
        val dueDate = view.findViewById<TextView>(R.id.textview_dueDate)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ArchivedViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.activity_archived_recycler_view_adapter, parent, false)
        return ArchivedViewHolder(view)
    }

    override fun getItemCount(): Int {
        return archivedActivities.size
    }

    override fun onBindViewHolder(holder: ArchivedViewHolder, position: Int) {
        val item = archivedActivities[position]

        holder.title.setText(item.title)
        holder.dueDate.setText(item.dueDate)
    }


}