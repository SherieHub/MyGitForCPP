package cit.edu.chatmessenger

import java.io.Serializable

data class Subject (
    val subjectName: String,
    val subjectCode: String,
    val gradeLevel: String,
    val roomNumber: String,
    val time: String
) : Serializable