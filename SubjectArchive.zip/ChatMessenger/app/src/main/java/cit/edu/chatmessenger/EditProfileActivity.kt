package cit.edu.chatmessenger

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class EditProfileActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)

        val et_username = findViewById<EditText>(R.id.et_username)
        val et_password = findViewById<EditText>(R.id.et_password)
        val btn_save = findViewById<Button>(R.id.btn_save)

        et_username.setText((application as MyApplication).username)
        et_password.setText((application as MyApplication).password)

        btn_save.setOnClickListener {
            val username = et_username.text.toString()
            val password = et_password.text.toString()

            if(username.isNotEmpty() || password.isNotEmpty()) {
                (application as MyApplication).username = username
                (application as MyApplication).password = password
            }
            startActivity(Intent(this, ProfileActivity::class.java))
        }
    }
}