package cit.edu.chatmessenger

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class ProfileActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val et_username = findViewById<EditText>(R.id.et_username)
        val et_password = findViewById<EditText>(R.id.et_password)
        val btn_editprofile = findViewById<Button>(R.id.btn_editprofile)

        val name = (application as MyApplication).username
        val password = (application as MyApplication).password

        et_username.setText(name)
        et_password.setText(password)

        btn_editprofile.setOnClickListener {
            startActivity(Intent(this, EditProfileActivity::class.java))
        }
    }
}