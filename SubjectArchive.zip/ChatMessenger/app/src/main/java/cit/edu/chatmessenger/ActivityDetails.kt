package cit.edu.chatmessenger

data class ActivityDetails (
    val title: String,
    val dueDate: String
)