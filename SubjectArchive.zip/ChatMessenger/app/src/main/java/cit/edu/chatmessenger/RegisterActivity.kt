package cit.edu.chatmessenger

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class RegisterActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val et_username = findViewById<EditText>(R.id.et_username)
        val et_password = findViewById<EditText>(R.id.et_password)
        val btn_register = findViewById<Button>(R.id.btn_register)

        btn_register.setOnClickListener {
            val username = et_username.text.toString()
            val password = et_password.text.toString()
            if(username.isEmpty() || password.isEmpty()){
                Toast.makeText(this, "All fields must be filled in!", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            (application as MyApplication).username = username
            (application as MyApplication).password = password

            startActivity(
                Intent(this, LoginActivity::class.java).apply {
                    putExtra("username", username)
                    putExtra("password", password)
                }
            )
        }
    }
}