package cit.edu.chatmessenger

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ClassActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_class)

        val recyclerClass = findViewById<RecyclerView>(R.id.recyclerview_classActivities)
        val btn_edit = findViewById<Button>(R.id.btn_edit)

        val classActivitylist = mutableListOf(
            ActivityDetails("Stack", "May 25, 2025"),
            ActivityDetails("Recycler View", "April 5, 2025"),
            ActivityDetails("Exceptions", "January 21, 2025")
        )
        val adapter = ClassRecyclerViewAdapter(classActivitylist, this)

        recyclerClass.adapter = adapter
        recyclerClass.layoutManager = LinearLayoutManager(this)
    }
}