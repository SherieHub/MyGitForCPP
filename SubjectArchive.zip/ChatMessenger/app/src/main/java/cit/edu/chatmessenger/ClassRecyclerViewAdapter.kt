package cit.edu.chatmessenger

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ClassRecyclerViewAdapter(
    private val activities : MutableList<ActivityDetails>,
    private val context: Context
) : RecyclerView.Adapter<ClassRecyclerViewAdapter.ClassViewHolder>(){

    class ClassViewHolder(view: View): RecyclerView.ViewHolder(view){
        val title = view.findViewById<TextView>(R.id.textview_title)
        val dueDate = view.findViewById<TextView>(R.id.textview_dueDate)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ClassViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.activity_class_recycler_view_adapter, parent, false)
        return ClassViewHolder(view)
    }

    override fun getItemCount(): Int {
        return activities.size
    }

    override fun onBindViewHolder(holder: ClassViewHolder, position: Int) {
        val item = activities[position]

        holder.title.setText(item.title)
        holder.dueDate.setText(item.dueDate)

        holder.itemView.setOnLongClickListener{
            val removed = activities.removeAt(position)
            notifyItemRemoved(position)

            (context.applicationContext as MyApplication).archivedActivities.add(removed)
            context.startActivity(Intent(context, ArchivedActivity::class.java))
            true
        }
    }
}