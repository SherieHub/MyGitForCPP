package cit.edu.chatmessenger

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class LoginActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val et_username = findViewById<EditText>(R.id.et_username)
        val et_password = findViewById<EditText>(R.id.et_password)
        val btn_login = findViewById<Button>(R.id.btn_login)

        intent?.let {
            it.getStringExtra("username")?.let { username ->
                et_username.setText(username)
            }
            it.getStringExtra("password")?.let { password ->
                et_password.setText(password)
            }
        }

        val valid_username = (application as MyApplication).username
        val valid_password = (application as MyApplication).password

        btn_login.setOnClickListener {
            val username = et_username.text.toString()
            val password = et_password.text.toString()

            if(username.isEmpty() || password.isEmpty()){
                Toast.makeText(this, "All fields must be filled in!", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            if(username.equals(valid_username) && password.equals(valid_password)){
                startActivity(
                    Intent(this, HomeActivity::class.java).apply {
                        putExtra("username", username)
                    }
                )
                Toast.makeText(this, "Successfullly logged in!", Toast.LENGTH_LONG).show()
            }else{
                Toast.makeText(this, "Enter valid username of password", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
        }
    }
}