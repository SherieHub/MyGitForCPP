package cit.edu.chatmessenger

import android.app.Application

class MyApplication : Application() {
    var username: String =  ""
    var password: String = ""
    var archivedActivities = mutableListOf<ActivityDetails>()

    override fun onCreate() {
        super.onCreate()
    }
}