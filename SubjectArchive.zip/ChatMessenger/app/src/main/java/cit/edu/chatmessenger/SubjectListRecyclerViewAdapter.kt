package cit.edu.chatmessenger

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class SubjectListRecyclerViewAdapter(
    private val subject: List<Subject>,
    private val onClick: (Subject) -> Unit
) : RecyclerView.Adapter<SubjectListRecyclerViewAdapter.SubjectViewHolder>(){

    class SubjectViewHolder(view: View) : RecyclerView.ViewHolder(view){
        val subjectName = view.findViewById<TextView>(R.id.textview_subjectname)
        val subjectCode = view.findViewById<TextView>(R.id.textview_subjectcode)
        val gradeLevel = view.findViewById<TextView>(R.id.textview_gradelevel)
        val roomNumber = view.findViewById<TextView>(R.id.textview_roomnumber)
        val time = view.findViewById<TextView>(R.id.textview_time)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SubjectViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.activity_subject_list_recycler_view, parent, false)
        return SubjectViewHolder(view)
    }

    override fun getItemCount(): Int {
        return subject.size
    }

    override fun onBindViewHolder(holder: SubjectViewHolder, position: Int) {
        val item = subject[position]
        holder.subjectName.setText(item.subjectName)
        holder.subjectCode.setText(item.subjectCode)
        holder.gradeLevel.setText(item.gradeLevel)
        holder.roomNumber.setText(item.roomNumber)
        holder.time.setText(item.time)

        holder.itemView.setOnClickListener {
            onClick(item)
        }
    }
}